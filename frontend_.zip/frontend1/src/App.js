import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import SearchBook from './Component/Search/SearchBook';
//import LoginSignup from './Component/LoginSignup/LoginSignup';



// Import the Homepage component
import HomePage from './Component/Home/HomePage';
import Login from './Component/Login/Login';
import Signup from './Component/Signup/Signup';
import AddCart from './Component/Cart/AddCart';
 import AddBook from './Component/Book/AddBook';
import ViewBook from './Component/Book/ViewBook';
import ViewCart from './Component/Cart/ViewCart';
import PlaceOrder from './Component/Order/PlaceOrder';
import ViewOrder from './Component/Order/ViewOrder';
import ViewTrackNo from './Component/Order/ViewTrackNo';
 import CreateCategory from './Component/Search/CreateCategory';
 import ViewCategories from './Component/Search/ViewCategories';

import About from './Component/About/About';
import ViewOrderByUser from './Component/Order/ViewOrderByUser';
import Footer from './Component/Footer/Footer';
import LoginNavbar from './Component/Admin/LoginNavbar';
import Contact from './Component/Contact/Contact';
// import CreateCategory from './Component/Search/CreateCategory;'





 //import DeleteBook from './Component/Book/DeleteBook';

 //import ViewBook from './Component/Book/ViewBook';
// import Home from './Component/Book/Home';




function App() {

  const userString = localStorage.getItem("user");
  let user = {};
 
  if (userString) {
    user = JSON.parse(userString);
  }
 
  const check=(user)=>{
       if(user.role==="Admin" || user.role==="User")
       {
        return true;
       }
       else{
        return false;
       }
  }
 
  const isrole = check(user);
 
 
  return (
    <>
    
    <div>

    <Router>
      <Routes>
        {/* <Route path="/searchBook" element={<SearchBook/>} /> */}
        {isrole && (
          <>
                  {/* <Route path ="/about" element ={<About/>}/> */}

        <Route path="/searchBook" element={<SearchBook/>} />
        <Route path ="/category" element={<CreateCategory/>} />
        <Route path ="/viewcat" element ={<ViewCategories/>}/> 
        <Route path ="/cart" element ={<AddCart/>} />
        <Route path ="/viewCart" element ={<ViewCart/>} />
        <Route path ="/addBook" element ={<AddBook/>}/>
        <Route path ="/viewBook" element ={<ViewBook/>}/>
        <Route path ="/placeorder" element ={<PlaceOrder/>} />
        <Route path ="/vieworder" element={<ViewOrder/>} />
        <Route path="/viewtrackno" element ={<ViewTrackNo/>} />
        <Route path ="/vieworderById" element ={<ViewOrderByUser/>}/>
        {/* <Route path ="/contact" element ={<Contact/>}/> */}

        
        </>)}
        <Route path="/searchBook" element={<SearchBook/>} />

        <Route path ="/about" element ={<About/>}/>
        <Route path="/" element={<HomePage />} />

        <Route path="/login" element ={<Login/>}/>
        <Route path="/signup" element ={<Signup/>}/>
s
        <Route path ="/contact" element ={<Contact/>}/>
     
        



      </Routes>
    </Router>
    <Footer/>
  </div>
  </>
    
  );
}

export default App;
