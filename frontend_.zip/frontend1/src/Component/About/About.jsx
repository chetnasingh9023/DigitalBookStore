import React from 'react'
import './About.css';

export default function AboutBooks() {
  return (
    <div>
      <div class="about-books-block">
        <div id="about-books-section">
          <div class="about-books-image">
            <img src="https://wallpapercave.com/wp/wp4430599.jpg" 
            style={{width: "120vh",
                    height: "100vh"}}  alt="Books Image" />
          </div>
          <div class="about-books-info">
            <h2>Discover the World of Books</h2>
            <p>Books are a window to the world, a source of knowledge, and a means of escape. Our platform is dedicated to providing you with a vast collection of books from various genres, authors, and publishers. Whether you're a bookworm or a casual reader, you'll find something that piques your interest.</p>
            <a href="#" title="About Books Button">ABOUT BOOKS</a>
          </div>
        </div>
        <div id="history-books-section">
          <div class="history-books-image">
            <img src="https://wallpapercave.com/wp/wp4430599.jpg" 
            style={{width: "120vh",
                    height: "100vh"}} width="951" height="471" alt="Books History Image" />
          </div>
          <div class="history-books-info">
            <h2>Preserving the Legacy of Books</h2>
            <p>Books have been around for centuries, preserving the knowledge and wisdom of our ancestors. Our platform is committed to preserving this legacy by providing a digital platform for books. We believe that books should be accessible to everyone, regardless of their location or circumstances. Join us in our mission to preserve the legacy of books for future generations.</p>
            <a href="#" title="Books History Button">BOOKS HISTORY</a>
          </div>
        </div>
      </div>
    </div>
  )
}