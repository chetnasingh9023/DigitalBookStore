import { useState } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';
import './Login.css';

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const location = useLocation();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get(`http://localhost:8080/user/${email}/${password}`)
      .then((res) => {
        localStorage.setItem('user', JSON.stringify(res.data));
        const user = JSON.parse(localStorage.getItem('user'));
  
  const userData = res.data;
      if (userData && userData.id) {
        localStorage.setItem("user", JSON.stringify(userData));
        const user = JSON.parse(localStorage.getItem("user"));
        if (user.role === "Admin") {
          navigate("/viewBook");
        } else {
          const book = location.state && location.state.book;
          if (book) {
            navigate("/cart", { state: { book } });
          } else {
            navigate("/searchBook");
          }
        }
      } else {
        setError("Invalid username or password");
      }
      })
      .catch((error) => {
        console.error('There was an error!', error);
        alert("Invalid username or password");
      });
  }

  return (
    <div>
      <div className='login'>
        <h1 className="abc">Login</h1>
        <form onSubmit={handleSubmit}>
          <div className="input">
            <label htmlFor="email">Email:</label>
            <input type="email" id="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </div>
          <div className="input">
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </div>
          <p>New User? <span onClick={() => navigate('/signup')} style={{color: 'blue', cursor: 'pointer'}}>Click here for Registration</span></p>
          {error && <p style={{color: 'red'}}>{error}</p>}
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;