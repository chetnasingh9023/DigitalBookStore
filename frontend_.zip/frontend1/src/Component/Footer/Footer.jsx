// import React from 'react';

// /**
//  * This component renders Footer
//  */
// function Footer() {
//   return (
//     <div style={footerStyle.container}>
//       <nav className="navbar navbar-dark" style={footerStyle.bg}>
//         <div className="container-fluid">
//           <span className="navbar-text">
//             Copyright © All rights reserved Chetna Singh, 2024.
//           </span>
//         </div>
//       </nav>
//     </div>
//   );
// };

// let footerStyle = {
//   container: {
//     position: 'fixed',
//     bottom: 0,
//     width: '100%',
//     height: '50px', // adjust the height as needed
//     backgroundColor: '#800000',
//     color: '#fff',
//     textAlign: 'center',
//     padding: '10px',
//   },
//   bg: {
//     background: '#800000',
//   },
// };

// export default Footer;



import React from 'react';

/**
 * This component renders Footer
 */
function Footer() {
  return (
    <div style={footerStyle.container}>
      <nav className="navbar navbar-dark" style={footerStyle.bg}>
        <div className="container-fluid">
          <span className="marquee" style={{color:'white'}}>
            Copyright © All rights reserved Chetna Singh, 2024.
          </span>
        </div>
      </nav>
    </div>
  );
};

let footerStyle = {
  container: {
    position: 'fixed',
    bottom: 0,
    width: '100%',
    height: '50px', // adjust the height as needed
    backgroundColor: '#800000',
    color: '#fff',
    textAlign: 'center',
    padding: '10px',
  },
  bg: {
    background: '#800000',
  },
};

// Add the Marquee CSS animation
const marqueeAnimation = `
  @keyframes marquee {
    0% { transform: translateX(100%); }
    100% { transform: translateX(-100%); }
  }

  .marquee {
    display: inline-block;
    white-space: nowrap;
    padding: 5px 10px;
    animation: marquee 10s linear infinite;
  }
`;

// Inject the Marquee CSS animation into the document head
const styleElement = document.createElement('style');
styleElement.innerHTML = marqueeAnimation;
document.head.appendChild(styleElement);

export default Footer;