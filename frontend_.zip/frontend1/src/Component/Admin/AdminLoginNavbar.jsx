
import React, { useState } from "react";
import { Link } from "react-router-dom";
 import book_logo from "../Assets/download.png";
//import './LoginNavbar.css';
 
function AdminLoginNavbar() {
  const userString = localStorage.getItem("user");
  let user = {};
 
  if (userString) {
    user = JSON.parse(userString);
  }
 
  const [dropdown, setDropdown] = useState(false);
 
  const signOut = () => {
    localStorage.clear();
  };
 
  return (
    <header>
 <nav>
  <Link to="/" className="image-link">
   <img src={book_logo} alt="BookLogo"  />
  </Link>
  <ul>
   <li> <Link to="/">Home</Link> </li>
   <li> <Link to="/viewBook">View Book</Link> </li>
   <li> <Link to="/addBook">Add Book</Link> </li>
    <li> <Link to="/vieworder">View Order</Link> </li>
   <li><Link to="/category">Add Category</Link></li>
   <li><Link to="/viewtrackno">ViewByTrackNo</Link></li>
  </ul>
  <ul>
   {user.name ? (
    <div className="dropdown" onClick={() => setDropdown(!dropdown)}>
     <Link to="#">Welcome {user.name}</Link>
     {dropdown && (
      <div className="dropdown-content">
       <Link to="/" onClick={signOut}>Sign Out</Link>
      </div>
     )}
    </div>
   ) : (
    <Link to="/login">Login / Register</Link>
   )}
  </ul>
 </nav>
</header>
  );
}
 
export default AdminLoginNavbar;