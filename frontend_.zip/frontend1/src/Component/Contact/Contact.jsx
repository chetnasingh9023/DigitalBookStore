import React, { useRef } from 'react';
import axios from 'axios';

const Contact = () => {
  const formRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(formRef.current);
    const contact = {
      id: formData.get('id'),
      name: formData.get('full_name'),
      email: formData.get('email'),
      phoneNumber: formData.get('phone_number'),
      feedback: formData.get('address'),
    };
    localStorage.setItem('contact', JSON.stringify(contact));
    axios.post('http://localhost:8080/post/contact', contact)
      .then(response => {
        console.log(response);
        formRef.current.reset();
        alert('Your message has been sent!');
      })
      .catch(error => {
        console.error(error);
        alert('Error sending message. Please try again later.');
      });
  };

  return (
    <div className="container-fluid p-0" style={{
      minHeight: '100vh',
      backgroundImage: `url(https://res.cloudinary.com/dqifboxk5/image/upload/v1686209968/contact-us-2_y8zzx7.jpg)`,
      backgroundSize: 'cover',
      margin: 0,
      padding: 0,
      boxSizing: 'border-box',
      fontFamily: '"Roboto", sans-serif'
    }}>
      <div className="row justify-content-center align-items-center h-100">
        <div className="col-md-6">
          <div className="card bg-light">
            <div className="card-body">
              <h2 className="card-title text-center mb-4">Contact Form</h2>
              <form className="form-wrapper" style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '15px'
              }} ref={formRef} onSubmit={handleSubmit}>
                <div className="form-card" style={{
                  position: 'relative',
                  width: '100%'
                }}>
                  <input
                    className="form-input form-control"
                    type="hidden"
                    name="id"
                    value={new Date().getTime()}
                  />
                  <input
                    className="form-input form-control"
                    type="text" name="full_name"
                    required="required"
                    placeholder="Full Name"
                    style={{
                      padding: '20px 25px 15px',
                      width: '100%',
                      border: '1px solid #000',
                      borderRadius: '5px',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: '20px',
                      lineHeight: '30px',
                      fontWeight: '400',
                      boxSizing: 'border-box'
                    }}
                  />
 
                </div>

                <div className="form-card" style={{
                  position: 'relative',
                  width: '100%'
                }}>
                  <input
                    className="form-input form-control"
                    type="email"
                    name="email"
                    required="required"
                    placeholder="Email"
                    style={{
                      padding: '20px 25px 15px',
                      width: '100%',
                      border: '1px solid #000',
                      borderRadius: '5px',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: '20px',
                      lineHeight: '30px',
                      fontWeight: '400',
                      boxSizing: 'border-box'
                    }}
                  />

                </div>

                <div className="form-card" style={{
                  position: 'relative',
                  width: '100%'
                }}>
                  <input
                    className="form-input form-control"
                    type="texr"
                    name="phone_number"
                    required="required"
                    placeholder="Phone number"
                    style={{
                        padding: '20px 25px 15px',
                        width: '100%',
                        border: '1px solid #000',
                        borderRadius: '5px',
                        background: 'transparent',
                        outline: 'none',
                        fontSize: '20px',
                        lineHeight: '30px',
                        fontWeight: '400',
                        boxSizing: 'border-box'
                      }}
                  />
 
                </div>

                <div className="form-card" style={{
                  position: 'relative',
                  width: '100%'
                }}>
                  <textarea
                    className="form-textarea form-control"
                    maxLength="420"
                    rows="3"
                    name="address"
                    required="required"
                    placeholder="FeedBack"
                    style={{
                      padding: '20px 25px 15px',
                      width: '100%',
                      border: '1px solid #000',
                      borderRadius: '5px',
                      background: 'transparent',
                      outline: 'none',
                      fontSize: '20px',
                      lineHeight: '30px',
                      fontWeight: '400',
                      display: '-webkit-box',
                      resize: 'none',
                      boxSizing: 'border-box'
                    }}
                  />

                </div>

                <button type="submit" className="form-submit-btn" style={{
                  padding: '10px 25px',
                  marginTop: '30px',
                  border: 'none',
                  borderRadius: '5px',
                  background: '#000',
                  color: '#fff',
                  fontSize: '20px',
                  lineHeight: '30px',
                  fontWeight: '400',
                  cursor: 'pointer',
                  outline: 'none',
                  textAlign: 'center',
                  position: 'relative'
                }}>Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  )
}

export default Contact;