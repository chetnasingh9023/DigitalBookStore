
import React from "react";
import { Link } from "react-router-dom";
import "./HomePage.css"; // Make sure the CSS file is imported in the new component
import book_logo from '../Assets/download3.png';
 
function Header() {
  return (
    <header>
      {/* <nav>
        
          <Link to="/" className="image-link">
            <img
             src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMwAAADACAMAAAB/Pny7AAAAdVBMVEX///8AAAAIBAOTk5MEAAAODQ37+/v39/fNzc1TU1Py8vLn5+fu7u7r6+vd3d3BwcHX19fHx8etra2np6e7u7tiYmJOTk6goKC1tbV1dXVDQ0M+Pj5dXV2ampp8fHxvb2+JiYkxMTEjIyMVFRUcHBwrKio3NzTCNJmmAAARWElEQVR4nO1c6ZaivBYlogmDQJjnEFR4/0e8J2FGtOurKkvvWuwf3aVNhWxyhn1OQivKjh07duzYsWPHjh07duzYsWPHjh07duzYsWPHjh07dnwDtmq/ewo/AF5+1CLtPfP4HbB4/knTF2QS9reT+Sl4NP+0IlOEfzuZn4KejNmnFRnk/PFsforFhJdkKCJ/PZsfopj7xZKMevnryfxnGOYihPnR7OOSTMTnF2Lz/MppfQ9uZc4/2s0stSzIGCc6v9CsPtCDrEidL42Re9OHBRkHza/DcfGJCTWp57MibOY0CzKsmP+WXXvKJ2KZPgJ98oU5GRz5s6swC1dq4UNA0dwZ7HYiMCezcCbFvn6gx0gwNPtgFeX485xM3M7TaV29flrfA77OFBlRJ6eZk0n5zK68yyIEfhQSZE0fHH20pxmZsz6zK4ym1Xs7sGksv8hmIYxG47RnZNx85jK8XXr/KvH+LSxeLmWWdpvsyUpHo5uRiYtp8WzkLn6bxKmlvA3Ey1ZsWDitlZ8OP09kMJv9QrUsBYif+e+UoDjJllZvt1MOdKIhVE9k7JnLJKdF7sd+5r0352CvXrDBcTTOkI4Tn8hMBJVzoS6G8mr/7fnTOy3Y2NHoKQaL+9lNZOJq9Iq4WYTl5DZXBu9CgBb1ftKMzl6G/cxHMkY6zpjmwfzXPPQZGs1Bc3sxGB+82Ml6mxrJ0GhggHk4j1zJh3ARebycWbtbDwHXHJxmJDMlUjefh+VPWRcBL58FXMyrQS8ztft6IINL1kfrc8qmGI695hP8ZUAyzze0Tfqf4r4MGMhY1eBeQTZlV8gvn7Muini20YxNmfVLo7WdVQ1kaNbbnaVPbvZmLsS9q3TxXAtYOe8v1Ls1Gsg4eh+N/WwMy2QrV9qusf7qVTiz+s7GsddOEToY1DNL5Tx7MmNVcJ5+H3v5HRf47g9FmuHXrbv+Mqkn09H1/ruLXK6ejKX3fNOpD+Xd9wDcqI6tvxQDVoWKdb/Lm/KN1eths6uRezJmn08pGr3fO92tcYWqP6/YzAaVq8cXTLUWv3V/dzq0J5PonVs1Y63s3+UXHzVUeQOSaxssJXsyssG9YuO5+LMjg6vOZbyx17zOlcRprwtt9Icw1KbSFnSSpk+TQxdNkz2OjgxpZGwzBi2HveuCC6Fpzd9YnVHWqgurSPKyC6qk65xj6R4dGbvrXvC2u5T4S9+31bx67wYbdsI8nvmrqNY6Nm4uE2QkOHVkSrkBpTVd4iT+vIGrmH5UJG/f6rCSLJzNAie9FiCsEqx8sX/Rkcm4+DqtZNhY5f0gzLyP6DrZcZNOWUewkdOlmXARE5k9mc7iklaa5bJG1ti1/JT2OabsysfnipO2yzexFC8iYEkyMhaYhWSK/Vnet/gtpW+3sAlE06/+uGOe3CQbWxdFfVX0ZJhwGS+TK+BdRhvDXp25H0RFAPvXeoxFfb7xRf53GtyREWztzuk9NFXPGSr/TFR+HYQhfZhWIJUNqaCCNg6aJGOC+MRlKCxvypUGaJc3ZpZnsKNT2Qu24Cr20RyxyRGp8oSGDy6j1aIF4KG+eDvHSH9vZnmKJMqSjg5oaCJ2ybCiRgpNqVKkEJYZgZh869blHGTZJ1XLmBCyFJtnNaoc6c4ye9ogWOxYISZRYk0JLhpw6XqexK0y1VoP9p5AgG3H80uVc1WN/cShUzlAecalrJTZs5x1obBfjrkSrmLTNgd1Ej9WxWhl7Dn231KyfRbWaMS11lPua733i2cu9CIoG9Uw5pHKOJM4SmApLVi/Phwbms9Tvb5Oo9UF8/8ug8Izn917ZJSFvK8Izk4eQYrB3l2VZaciV3qDZ5GAh9nGWCdJ+U9ASoQO4p43veJlHPsqC3M5iUbnnYa2fFRoCr4rfsU3tECxdBbK9Ub+WhYyNY7jklf6TXyGwcu/MjUcw+1yVTsL9+9AiGE6aiYJdnHXSrerX/g+lKuSRGLimeqYxmwYcnbVHIaP/2plsI+OaLu2dVMwmlvcdTH4luVb0u9JDExu7K4pIkFh+D/a3cAE8t8Bbc9DTCWF0OA/VSiGB26ePiz1XRjeV8jr6ZiayiGFH1Dw+JqzX5xq7SEdQ6tPxTO2AQyfKFzVXl3g6AjpcLfjQMY4W5Z1NlZPEQfVhT0Irza7VMH6+m6Y3um74eWdXgt5Cwc8t5MkppoKMNX3Am2x7x2k+qYluno1D7vYpIEXq0wOU3ZLAUaInL8gEyIUYeeEeg1v+rHneZC9WahHIY9nLWLDSzeOxTipN7tEi3mo6xCYS9+HUfyOjA+JxsERQi89lwp2kAIZw4WQtYyd2DCpm6hFHnJnzBA0uVP3VjK6PXF4mBdq4lJzaaUQ+dHNNYAMSNMXnRI0/BSEPIPUYLkQV9WNYENMmlRtpA6Oa9xlPjIsi6lGbZVQcyM3YlWQsSBpMagd0ueB8ZswC2HJHKHc1iBxsweR0zC97Fb9Q1vZ1S3z1kdVBmB4YI1mAxkOsQAVr4hpgkygwFNrNQriJX2SBmh431Wf4Vyg8Ek/GYMp51RrYfVfRsaqRAgDWVa7tnDOpzmNhIg9oHNmKHwqvLAIMrYLqbcUge0lZTWIKghh4Jy1Y8Mi6f9QgnaYext2ZHjtvw6YEgjKhe0AmVgEtpdsO52BTAmyDDWBCc8u68iYGoBSapvn9VK5UUXXyZFW0Tpe47NpwwBinM6gCHhLaAaNeHblq8gwEcJg3S+esLimIxNnuq5HWaYXrEy0ZY1olOuevsWXbSVia0nJCj3LIhim7wiQRthWcgGrFoHtkbn+CAYEMo4h+d98A3gdunlbtgmgmuOVPIx07i1ak+sCmCwOC1OP61HBS8/RqBjF7qgTKGeY4UP4d7C45ytCsyRDXCgpS3GP+5cTsKlB2oTE8KWa14a0BSlTuz/7R5B4aiUkZpe8kgwjGqyJKgI02rwHsd0yitg/m2Eai6LS3e5cGIKMooJk0gh7FRlgkBpU3gn8Ej3yS2y6VV083ZekRV25D49jWkhkGLH41ICgo76KTGXYI5knxkRshqqHc4DwwZ51k0wkgrIgYxsQadRXdAMIkAnPpiQTQ8Xx3DOs8NEp3xKFz4OtLapmScY8h68iA/lSt4QNMEU0AbpqRbYhRT/i7nqaZxuuo0X5vQV2rYyhOepKMkxYsgX5M34VmcgS3lkp3gn1paZbFUURMh4H1LSWt8Vxs7Z3Q21WbRdi2TSIOQthmKp7PqDHTp5SASXDil5ERpQZmWnAPSoluQ2lJlXVsuQMJpPlBQdNP58rXevJ5RdQZSZcz7MiTBlXS7Xft4a8fEuADARMM1sXTr9FBm6Sm1isDO60xgKG7UDZmIWxM1O51nplZt5iOjFcDsWpvbpIKiZJBpsgz1/TdAIyranAPULiSEl7D0uLWRTGXzgvQuMwYrG7JVWEMHdAdiOkmC160XlH0ewyFdAaoaHJymkTBvWqf2ZNyJmVRx8Eb4hjmWYAmYNi1q8ik4Atmwrov8KiT7sNlpvWzw4mmVWduo/DMxhYRC2oMi6KCb6ZPLzwJwAyJ1tpRO0nCpriyaWGHV62mgQCRL1UazdZQIxti7q2UezTC8lApoSF121R0ERPL8Y0zzdtTcvzdZWzglh104YMUytCb7ySTC5qWkGm/tf1PmJ3CwDFw8NtzIFiLckApfyFZIKBTKYREID96biyqXM9TGPHttZNWjOMVprHjsKVL2HDgpiehnreNH18BD9JiQgxmSTzpKn9IzIHIAM3yTXRDepfltM8z4t5VUR1G/rasg+G1eUGGE6WjkRMLQ7zNioqHvue15ulEExYExYgZdqryIhdGXDM3AXldETLfyV2wqss4q69eI92edH8I7YdHmUVD9YKGp4ZU9xchBj6fLvhB3AkGQicregFrslI2B6PilL7Qs7GWllE3NuS3kCAK04rNKAGt3nNe5yCjOzP1oEksz1lyJnZgx2xGVyWQdbc/jcYmitBLbuzLyRzADKQn5tEknmkZi2X5dXzSrPK2cOsSSSZpBEa41VksOnIIkYVvSb484get4AMmjaPS3fCG/Yka55haFXxLqJ2FqWN84LXHamqyT0gkIE3TymPCD3rARPImQ8eqZNnT0/KQS17KBXvJqSsfH7q759zrnsyUNVcfUV0tU6n07UuWBnYW48OKoZ0qz2bos1X/rAdlKyorzAo3CBWfLEFJLfoNLX5bS4pKrWryGCiYi6FFRzmRyp07lrr7WErvBc0Wr5uAGBiOao+H+sg7LiUO42Qp69aidLf5eKiU6lJCRt0ZG73Z0Ra7i63XHB581ZJ87asGw3TYe39SMKOpesLoa6Vp8f79N/B+QpkqOj+Sp8sIbRWEmFYRFl+OQ3TqBI6jwvOsglg8LkfnWlSjYdlmjyLijDsRoXQXspoIzrbFMhcf7HfjOGmQKYRZkxlsBn/xTBtzRXbxZXeSko3Fswy4Xm18zn9bAdMngA61HrF1DhxNXu+t6nKDB33ZFD1exHNu6JjR6aUcmmrYj5Tx1MraTPFv+tmGhfSMivVc+h27Sw6c+A5DZA5ouuv1Zs0QwdBphZ7GiY4aOUEQeA4jqstH6donXNxGijaPDYzwuaROAPEF21zschUcx0xduBUcBtTJLVakDmg7Jfi8zlFR0HGzkV33gJit7YWaPNMGHqVMtUbm+AG6Eewn0h9aOZnFaicuDMkTmK7nsrTCtwP/C/vhr4JMlhuBwsyR5T+jtv4B3QAMqrc/8Vn+HAXfk6XGmgxv8uGhukJzfsoaQrd3W81E+ozPcrqKYJMAfqAzhMZmMKvnE3Vahj4AAGgI0PuI+mI66XWVZlbMEj4E99I9IQfUOvKE/SaqteXjWOAI4ggkwEZOYH6Fw4Nm5UYCowWi5YMkGkggvbQs/ZyvX+oRSIeO9SK+p3n2AWSHWjDK+6X93RpM30cvGgkmYjirJvBz99EE6f+xEg3TRFk2JaqIibVEpXpedsMTzoKDPFCxvppao14udZI9GElmzbXUzXRNo9qiDPsQEaBbC3n8OPeptgpEwOp4j2F50cZOoGVFlEr5QGnxFDrheM4tWoQKrbd0A2KZSHrnp8ISJFcXbWbw+mHhmbq3TjiNThBpnABXfQUwRk+yJ1z2zbN86DNLDdmlTgTm7qEprMJuCklbirO2ULNP9QzmJxN07bl3rkc25nGdouOjJJ3s9B/Zmi8G0W+xgP2ftzy08OljfSwEuesEseltoihRPN4eIOEZASjsLQSA9LHLeSefOlOnIOSZ7NZFepRe7mPkYAjkkcgBvvgP+HiTEYmzlxAipF3gK+Om7zQtYnCVIgTeIamG4c1mzrKBmV1JVfEdBNxQi1qNmPZ8TjeALJlKINIZ2g/KjuNpuMSyacrOn9fxDUvwK3BabR4+C8BFKKmsQYu46lpkT+LyEt0jTYr6mZSfz91pr2RdQrcKoUleV4iDVqToN1fmnQkaTMpKM7bwIg7hkUTOR0zoZbh8IHHrdWFcoj9+WjaYjRPvGzAys5MBxv59v9T5R16Ixue7YPdyxHysLZhnC2Q0kGc6pCC6unoGa1qmJHO4gAUnXWGC58P1+909vfuI9rhm4rT7mPIusf6ZWBs0IRdLrKNlzQXllDj2bN4Ppve0PJvzQYXvZH9uKVIA4M4P1a9QW8nxXceRyeJjmhLYb0DBpdhFJ2+8b+Iab0iit7yQvsW6GBo/7kjYPX68iP+z6Eefq/R/utBR/mKjDCyrd7Xu0DSztD+6zkHt0+Xzae8cSxB+1nV/8nQzp2+PB5eswf3bSSHY6c4/4MQwKpcT1ErfxhO3bw2z7s/AO20A/yW6P1+EK7Hbl7owYtVWxi4CO36WRjmhR5sdd0jHLl8Lr76OkqA/h/IfE1l2fftlo/E6StZI3h3xPoqXrOnvmPHjh07duzYsWPHjh07duzYsWPHjh07duzYsWPH/z/+B2gDJcmcrxS8AAAAAElFTkSuQmCC"  
           // src=".\booklogo.png"
            alt="BookX Logo"
            />
          </Link>
         */}

      <nav>
              <Link to="/" className="image-link">
               <img src={book_logo} alt="BookLogo" />
              </Link>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
          {/* <li>
            <Link to="/signup">Signup</Link>
          </li> */}

          {/* <li>
            <Link to="/cart">Cart</Link>
          </li> */}
          {/* <li>
            <Link to="/">MyOrder</Link>
          </li> */}


          <li>
            <Link to="/about">About Us</Link>
          </li>
          <li>
            <Link to="/contact">Contact Us</Link>
          </li>



        </ul>
      </nav>
    </header>
  );
}
 
export default Header;