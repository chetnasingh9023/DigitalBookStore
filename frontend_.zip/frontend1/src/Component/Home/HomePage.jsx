import Header from "./Header";
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div>
      <Header/>
      <div
        className="bg-image d-flex justify-content-center align-items-center flex-column"
        style={{
          position: 'relative',
          height: "100vh",
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
          }}
        />
        <div>
          <h1 className="text-white">Digital Book Store</h1>
        </div>
        
        <div style={{position: 'absolute', bottom: '120px'}}>
          <h4 className="text-white">Turning Pages into Pixels: Your Gateway to the Digital Library</h4>
          <button type="button" style={{display:'block',color:'white'}} onClick={() => navigate('/searchBook')}>Search Book</button>
        </div>
      </div>
    </div>
  )
}