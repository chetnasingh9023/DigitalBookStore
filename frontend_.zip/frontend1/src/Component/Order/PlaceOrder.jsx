import React, { useEffect, useState } from 'react';
import axios from 'axios';
import LoginNavbar from '../Admin/LoginNavbar';

function PlaceOrder() {
  const [cart, setCart] = useState([]);
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    // Retrieve cart data from local storage or API
    const storedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCart(storedCart);
  }, []);

  const handlePlaceOrder = () => {
    const user = JSON.parse(localStorage.getItem('user')) || {};
    const order = {
      user: {
        id: user.id 
      },
      // items: cart.map(item => ({
      //   productId: item.productId,
      //   quantity: item.quantity,
      //   price: item.price
      // }))
    };

    axios.post('http://localhost:8080/post/orders', order)
      .then(response => {
        console.log(response.data);
        // Clear cart after successful order placement
        setCart([]);
        localStorage.removeItem('cart');

        // Show alert message
        setShowAlert(true);
      })
      .catch(error => {
        console.error('Error making POST request:', error);
        alert('Error placing order. Please try again.');
      });
  };

  return (
    <>
    <LoginNavbar/>
    <div style={{textAlign:'center',margin:'auto'}}>
      <h1>Place Order</h1>
      <button onClick={handlePlaceOrder}>Confirm Order</button>
      {showAlert && (
        <div className="alert alert-success" role="alert">
       <h3>  Order placed successfully!</h3>
        </div>
      )}
    </div>
    </>
  );
}

export default PlaceOrder;