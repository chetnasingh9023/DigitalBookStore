// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import AdminLoginNavbar from '../Admin/AdminLoginNavbar';

// const ViewOrder = () => {
//   const [orders, setOrders] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [userId, setUserId] = useState(null);
//   const [userRole, setUserRole] = useState(null);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const user = JSON.parse(localStorage.getItem('user'));
//         setUserId(user.id);
//         setUserRole(user.role);
//         const response = await axios.get(`http://localhost:8080/orders?userId=${userId}`);
//         setOrders(response.data);
//         setLoading(false);
//       } catch (error) {
//         console.log(error);
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, [userId]);

//   if (loading) {
//     return <p>Loading...</p>;
//   }

//   if (userRole !== 'Admin') {
//     alert('You do not have permission to view this page. Redirecting to homepage...');
//     window.location.href = '/';
//     return null;
//   }

//   return (
//     <>
//       <AdminLoginNavbar/>
//       <table>
//         <thead>
//           <tr class ="tr1">
//             <th>Order ID</th>
//             <th>Order Tracking Number</th>
//             <th>Total Quantity</th>
//             <th>Total Price</th>
//             <th>Status</th>
//             <th>Date Created</th>
//             <th>Last Updated</th>
//             <th>User ID</th>
//             <th>User Email</th>
//             <th>User Name</th>
//             <th>User Phone Number</th>
//             <th>User Total Orders</th>
//           </tr>
//         </thead>
//         <tbody>
//           {orders.map((order) => (
//             <tr key={order.id}>
//               <td>{order.id}</td>
//               <td>{order.orderTrackingNumber}</td>
//               <td>{order.totalQuantity}</td>
//               <td>{order.totalPrice}</td>
//               <td>{order.status}</td>
//               <td>{order.dateCreated}</td>
//               <td>{order.lastUpdate}</td>
//               <td>{order.user.id}</td>
//               <td>{order.user.email}</td>
//               <td>{order.user.name}</td>
//               <td>{order.user.phoneNumber}</td>
//               <td>{order.user.totalOrder}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </>

//   );
// };

// export default ViewOrder;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AdminLoginNavbar from '../Admin/AdminLoginNavbar';

const ViewOrder = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(null);
  const [userRole, setUserRole] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        setUserId(user.id);
        setUserRole(user.role);
        const response = await axios.get(`http://localhost:8080/orders?userId=${userId}`);
        setOrders(response.data);
        setLoading(false);
      } catch (error) {
        console.log(error);
        setLoading(false);
      }
    };

    fetchData();
  }, [userId]);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (userRole!== 'Admin') {
    alert('You do not have permission to view this page. Redirecting to homepage...');
    window.location.href = '/';
    return null;
  }

  return (
    <>
      <AdminLoginNavbar />
      <table className="table table-bordered table-dark">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Order Tracking Number</th>
            <th>Total Quantity</th>
            <th>Total Price</th>
            <th>Status</th>
            <th>Date Created</th>
            <th>Last Updated</th>
            <th>User ID</th>
            <th>User Email</th>
            <th>User Name</th>
            <th>User Phone Number</th>
            <th>User Total Orders</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.orderTrackingNumber}</td>
              <td>{order.totalQuantity}</td>
              <td>{order.totalPrice}</td>
              <td>{order.status}</td>
              <td>{order.dateCreated}</td>
              <td>{order.lastUpdate}</td>
              <td>{order.user.id}</td>
              <td>{order.user.email}</td>
              <td>{order.user.name}</td>
              <td>{order.user.phoneNumber}</td>
              <td>{order.user.totalOrder}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default ViewOrder;


