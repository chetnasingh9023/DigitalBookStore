
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import LoginNavbar from '../Admin/LoginNavbar';
import 'bootstrap/dist/css/bootstrap.min.css';

const ViewOrderByUser = () => {
  const [order, setOrder] = useState(null);
  const userId = JSON.parse(localStorage.getItem('user')).id;

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/order/user/${userId}`);
        const orderData = response.data;
        console.log(orderData);
        // const totalQuantity = orderData.orderItems ? orderData.orderItems.reduce((acc, item) => acc + item.quantity, 0) : 0;
        // const totalPrice = orderData.totalPrice ? orderData.totalPrice : 0;
        setOrder(orderData);
      } catch (error) {
        console.error('Error fetching order:', error);
      }
    };

    fetchOrder();
  }, [userId]);

  if (order === null) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <LoginNavbar />
      <h2 className="text-center">Order Details</h2>
      <div className="container">
        <table className="table table-bordered">
          <thead>
            <tr class="tr1">
              <th>ID</th>
              <th>Order Tracking Number</th>
              <th>Total Quantity</th>
              <th>Total Price</th>
              <th>Status</th>
              <th>Date Created</th>
              <th>Last Update</th>
            </tr>
          </thead>
          <tbody>
            {order.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.orderTrackingNumber}</td>
                <td>{order.totalQuantity}</td>
                <td>{order.totalPrice}</td>
                <td>{order.status}</td>
                <td>{order.dateCreated}</td>
                <td>{order.lastUpdate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default ViewOrderByUser;