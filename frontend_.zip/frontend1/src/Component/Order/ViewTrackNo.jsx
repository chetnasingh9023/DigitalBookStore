
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AdminLoginNavbar from '../Admin/AdminLoginNavbar';
import { Container, Row } from 'react-bootstrap';

function ViewTrackNumber() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [trackNumber, setTrackNumber] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const response = await axios.get('http://localhost:8080/orders');
      setOrders(response.data);
      setLoading(false);
    };

    fetchData();
  }, []);

  const handleViewDetails = (order) => {
    localStorage.setItem('selectedOrder', JSON.stringify(order));
    setTrackNumber(order.orderTrackingNumber);
  };

  return (
    <>
      <AdminLoginNavbar />
      <Container fluid style={{ padding: 0 }}>
        <Row style={{ marginTop: 50, width: '100%', display: 'flex', justifyContent: 'center' }}>
          <div className="col-md-10" style={{ backgroundColor: '#f2f2f2', padding: 0, borderRadius: 5, border: '1px solid #ddd' }}>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <>
                <table className="table table-bordered">
                  <thead>
                    <tr>
                      <th style={{ padding: '4px', textAlign: 'left' }}>Order ID</th>
                      <th style={{ padding: '4px', textAlign: 'left' }}>Order Tracking Number</th>
                      <th style={{ padding: '4px', textAlign: 'left' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order) => (
                      <tr key={order.id}>
                        <td style={{ padding: '4px' }}>{order.id}</td>
                        <td style={{ padding: '4px' }}>{order.orderTrackingNumber}</td>
                        <td style={{ padding: '4px' }}>
                          <button onClick={() => handleViewDetails(order)}>
                            View Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {trackNumber && (
                  <ViewOrderDetails trackNumber={trackNumber} />
                )}
              </>
            )}
          </div>
        </Row>
      </Container>
    </>
  );
}

function ViewOrderDetails({ trackNumber }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    const order = JSON.parse(localStorage.getItem('selectedOrder'));
    if (order) {
      setData(order);
    }
  }, [trackNumber]);

  if (!data) {
    return <p>Loading...</p>;
  }

  return (
    <div style={{ maxWidth: '100%', overflowX: 'auto' }}>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th style={{ padding: '4px', textAlign: 'left' }}>Order ID</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>Tracking Number</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>Total Quantity</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>Total Price</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>Status</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>Date Created</th>
            <th style={{ padding: '4px', textAlign: 'left'}}>Last Updated</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>User ID</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>User Email</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>User Name</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>User Phone Number</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>User Total Orders</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ padding: '4px' }}>{data.id}</td>
            <td style={{ padding: '4px' }}>{data.orderTrackingNumber}</td>
            <td style={{ padding: '4px' }}>{data.totalQuantity}</td>
            <td style={{ padding: '4px' }}>{data.totalPrice}</td>
            <td style={{ padding: '4px' }}>{data.status}</td>
            <td style={{ padding: '4px' }}>{data.dateCreated}</td>
            <td style={{ padding: '4px' }}>{data.lastUpdate}</td>
            <td style={{ padding: '4px' }}>{data.user.id}</td>
            <td style={{ padding: '4px' }}>{data.user.email}</td>
            <td style={{ padding: '4px' }}>{data.user.name}</td>
            <td style={{ padding: '4px' }}>{data.user.phoneNumber}</td>
            <td style={{ padding: '4px' }}>{data.user.totalOrder}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default ViewTrackNumber;