import React, { useState } from 'react';
import axios from 'axios';
import AdminLoginNavbar from '../Admin/AdminLoginNavbar';

const CreateCategory = () => {
  const [categoryName, setCategoryName] = useState('');

  // Check if the user has the Admin role
  const user = JSON.parse(localStorage.getItem('user'));
  if (user && user.role !== 'Admin') {
    alert('You do not have permission to access this page. Redirecting to homepage...');
    window.location.href = '/';
    return null;
  }

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/post/categories', {
        categoryName,
      });

      // Save the new category to local storage
      const categories = JSON.parse(localStorage.getItem('categories')) || [];
      categories.push(response.data);
      localStorage.setItem('categories', JSON.stringify(categories));

      // Save the category name to local storage
      localStorage.setItem('categoryName', categoryName);

      // Clear the form
      setCategoryName('');

      // Show alert message
      alert(`Category "${categoryName}" added successfully.`);
    } catch (error) {
      console.error('Error creating category:', error);
      alert('Error creating category. Please try again.');
    }
  };

  return (
    <>
    <AdminLoginNavbar/>
    <div style={{ textAlign: 'auto', margin: 'auto', marginTop: '3%',borderRadius:'10%',boxShadow: '0px 0px 10px 1px rgba(0, 0, 0, 0.2)' , alignItems: 'center', padding: '20px', border: '2px solid black', backgroundColor: 'black', width: '30%'  }}>
  <h1 style={{ marginTop: "0", display: "inline-block",color:'white' }}>Create Category</h1>
    <form onSubmit={handleSubmit}>
      <label htmlFor="categoryName">Category Name:</label>
      <input
        type="text"
        id="categoryName"
        value={categoryName}
        onChange={(event) => setCategoryName(event.target.value)}
      />
      <button type="submit">Create Category</button>
    </form>
    </div>
    </>
  );
};

export default CreateCategory;