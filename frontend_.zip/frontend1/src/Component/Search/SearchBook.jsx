


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import "./SearchBook.css";
import LoginNavbar from '../Admin/LoginNavbar';

const BookDetails = ({ book, addToCart }) => {
  const [quantity, setQuantity] = useState(1);

  const handleQuantityChange = (event) => {
    setQuantity(event.target.value);
  };

  return (
    <table className="table table-dark table-striped table-bordered">
      <thead>
        <tr>
          <th>Name</th>
          <th>Author</th>
          <th>Publisher</th>
          <th>Description</th>
          <th>Image</th>
          <th>Add to Cart</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>{book.name}</td>
          <td>{book.author}</td>
          <td>{book.publisher}</td>
          <td>{book.description}</td>
          <td><img src={book.imageUrl} alt="" /></td>
          <td>
            <button className="btn btn-primary" onClick={() => addToCart(book, quantity)}>Add to Cart</button>
          </td>
        </tr>
      </tbody>
    </table>
  );
};

const SearchBook = () => {
  const [name, setName] = useState('');
  const [book, setBook] = useState(null);
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  const searchBook = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/b/${name}`);
      setBook(response.data);
      localStorage.setItem("book", JSON.stringify(response.data));

    } catch (error) {
      console.error('Error searching for book:', error);
      setBook(null);
    }
  };

  useEffect(() => {
    if (name) {
      searchBook();
    }
  }, [name]);

  const addToCart = (book, quantity) => {
    setCart([...cart, {...book, quantity }]);
    const user = localStorage.getItem('user');
    if (user) {
      navigate('/cart',{state:{book}});
    } else {
    navigate('/login',{state:{book}});
    }
  };

  return (
    <>
      <LoginNavbar/>
      <div>
        <h1 className="sk" >Search for a Book</h1>
        <div className="searchbook">
          <input
            type="text"
            placeholder="Enter book name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <br />
          <button className="btn btn-primary" onClick={searchBook}>Search</button>
        </div>
        {book && <BookDetails book={book} addToCart={addToCart} />}
      </div>
    </>
  );
};

export default SearchBook;



