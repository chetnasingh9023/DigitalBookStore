import React, { useState, useEffect } from 'react';
import axios from 'axios';
// import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoginNavbar from '../Admin/LoginNavbar';

const ViewCategories = () => {
  const [categories, setCategories] = useState(JSON.parse(localStorage.getItem('categories')) || []);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [books, setBooks] = useState([]);
  const [cart, setCart] = useState([]); // add cart state

  useEffect(() => {
    if (selectedCategory) {
      axios.get(`http://localhost:8080/cat/${selectedCategory}`)
       .then(response => {
          localStorage.setItem('books', JSON.stringify(response.data));
          setBooks(response.data);
        })
       .catch(error => {
          console.error('Error retrieving books:', error);
        });
    }
  }, [selectedCategory]);

  const handleCategorySelect = (event) => {
    setSelectedCategory(event.target.value);
  };

  const handleAddToCart = (book) => {
    // add book to cart state
    setCart([...cart, book]);
    // navigate to login page
    window.location.href = '/login';
  };

  return (
    <>
    <LoginNavbar/>

<div className="container">
  <label htmlFor="categories">Select Category:</label>
  <select id="viewcategories" value={selectedCategory} onChange={handleCategorySelect} className="form-control">
    <option value="">Select a category</option>
    {categories.map((category) => (
      <option key={category.id} value={category.categoryName}>
        {category.categoryName}
      </option>
    ))}
  </select>
  <hr />
  {selectedCategory && (
    <table className="table">
      <thead>
        <tr>
          <th style={{ backgroundColor: '#f8d7da' }}>ID</th>
          <th style={{ backgroundColor: '#f8d7da' }}><strong>Name</strong></th>
          <th style={{ backgroundColor: '#f8d7da' }}>Description</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Unit Price</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Author</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Publisher</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Units in Stock</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Category</th>
          <th style={{ backgroundColor: '#f8d7da' }}>Add to Cart</th>
        </tr>
      </thead>
      <tbody>
        {books.map((book) => (
          <tr key={book.id}>
            <td>{book.id}</td>
            <td>{book.name}</td>
            <td>{book.description}</td>
            <td>{book.unitPrice}</td>
            <td>{book.author}</td>
            <td>{book.publisher}</td>
            <td>{book.unitsInStock}</td>
            <td>{book.category.categoryName}</td>
            <td>
              <button className="btn btn-primary" onClick={() => handleAddToCart(book)}>Add to Cart</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )}
</div>
    </>
  );
};

export default ViewCategories;