// 
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EmptyCart from './EmptyCart';
import './ViewCart.css';
import LoginNavbar from '../Admin/LoginNavbar';

function ViewCart() {
  const [cartData, setCartData] = useState([]);
  const [selectedCart, setSelectedCart] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    getCarts();
  }, []);

  const getCarts = () => {
    axios.get('http://localhost:8080/carts')
      .then(res => {
        setCartData(res.data);
      })
      .catch(err => {
        console.log(err);
      });
  }

  const handleDelete = (cartId) => {
    console.log(cartId);
    axios.delete(`http://localhost:8080/carts/${cartId}`)
      .then(res => {
        setCartData(cartData.filter(cart => cart.id !== cartId));
        alert("Cart deleted successfully");
        getCarts();
      })
      .catch(err => {
        console.log(err);
        alert("Error deleting cart");
      });
  }

  const handleUpdate = (cartToUpdate) => {
    setSelectedCart(cartToUpdate);
  }

  const handleSave = () => {
    axios.put(`http://localhost:8080/put/carts`, selectedCart)
      .then(res => {
        setCartData(cartData.map(cart => cart.id === selectedCart.id ? selectedCart : cart));
        setSelectedCart(null);
        alert("Cart updated successfully");
      })
      .catch(err => {
        console.log(err);
        alert("Error updating cart");
      });
  }

  const handlePlaceOrder = () => {
    navigate('/placeorder');
  }

  const handleSelect = (id, value) => {
    if (value === 'update') {
      const cartToUpdate = cartData.find(cart => cart.id === id);
      handleUpdate(cartToUpdate);
    } else if (value === 'delete') {
      handleDelete(id);
    }
  };

  return (
    <>
      <LoginNavbar/>
      <div>
        {cartData.length === 0 ? (
          <EmptyCart />
        ) : (
          <table className="table table-bordered">
            <thead>
              <tr>
                <th>Cart Id</th>
                <th>Book Name</th>
              
                <th>Quantity</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {cartData.map((cart, index) => (
                <tr key={index}>
                  <td>{cart.id}</td>
                  <td>{cart.book.name}</td>
                
                  <td>{cart.quantity}</td>
                  <td>
                    <select onChange={(event) => handleSelect(cart.id, event.target.value)}>
                      <option>Action</option>
                      <option value="update">Update</option>
                      <option value="delete">Delete</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {selectedCart && (
          <>
            <h1 style={{textAlign:'center'}}>Update Cart Details</h1>
            <div style={{ textAlign: 'auto', margin: 'auto', marginTop: '3%',borderRadius:'10%',boxShadow: '0px 0px 10px 1px rgba(0, 0,0, 0.2)' , alignItems: 'center', padding: '20px', border: '2px solid white', backgroundColor: 'white', width: '30%' }}>
              <form>
                <label style={{ marginRight: '10px' }}>
                  Quantity:
                  <input
                    type="number" id="quantity" name="quantity" value={selectedCart.quantity} onChange={(e) => setSelectedCart({ ...selectedCart, quantity: e.target.value })}
                  />
                </label>
                <button
                  type="submit" onClick={handleSave}
                  style={{
                    backgroundColor: '#4CAF50',
                    color: 'white',
                    padding: '10px 20px',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '50%',
                  }}
                >
                  Save to Cart
                </button>
              </form>
            </div>
          </>
        )}
      </div>
      {cartData.length > 0 && (
        <button type="placeorder" style={{
          display: "block",
          margin: " auto",
          padding: "12px 17px",
          width: "120px",
          backgroundColor: "blue",
          color: "#ffffff",
          // marginBottom:'20%',
        }} onClick={handlePlaceOrder} >Place Order</button>
      )}
    </>
  );
}

export default ViewCart;