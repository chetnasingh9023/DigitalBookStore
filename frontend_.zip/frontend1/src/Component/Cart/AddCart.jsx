// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
//  import './AddCart.css';
// import LoginNavbar from '../Admin/LoginNavbar';




// const AddCart = () => {
//   const [quantity, setQuantity] = useState(1);
//   const [user, setUser] = useState(null);
//   const [book, setBook] = useState(null);
//   const navigate = useNavigate();
//   const [cartData, setCartData] = useState([]);
//   const [selectedCart, setSelectedCart] = useState(null);

//   useEffect(() => {
//     const userFromLocalStorage = JSON.parse(localStorage.getItem('user'));
//     const bookFromLocalStorage = JSON.parse(localStorage.getItem('book'));
// // navigate(1); // Refresh the page
  


//     if (userFromLocalStorage && bookFromLocalStorage) {
//       setUser(userFromLocalStorage);
//       setBook(bookFromLocalStorage);
//     }
//     handleSubmit();

//   },[]);
  


//   const handleSubmit = async (event) => {
//      event.preventDefault();

//     if (!user ||!book) {
//       alert('User or book not found in local storage');
//       return;
//     }

//     try {
//       const response = await axios.post('http://localhost:8080/post/carts', {
//         quantity,
//         book: { id: book.id },
//         user: { id: user.id },
//       });

//       if (response.status === 200) {
//         alert('Cart added successfully');
//          navigate("/viewCart");
//       } else {
//         alert('Failed to add cart');
//       }
//     } catch (error) {
//       console.error(error);
//       alert('Failed to add cart');
//     }
//   };

//   const handleViewCart = () => {
//     navigate("/viewCart");
//   };

//   const handleSave = () => {
//     axios.put(`http://localhost:8080/put/carts`, {
//         quantity: selectedCart.quantity,
//         user: { id: selectedCart.user.id },
//         book: { id: selectedCart.book.id },
//       })
//       .then(res => {
//         setCartData(cartData.map(cart => cart.id === selectedCart.id ? selectedCart : cart));
//         setSelectedCart(null);
//         alert("Cart updated successfully");
//       })
//       .catch(err => {
//         console.log(err);
//         alert("Error updating cart");
//       });
//   }

//   return (
//     <>
//     <LoginNavbar/>
//     <div style={{ textAlign: 'auto', margin: 'auto', marginTop: '3%',borderRadius:'10%',boxShadow: '0px 0px 10px 1px rgba(0, 0, 0, 0.2)' , alignItems: 'center', padding: '20px', border: '2px solid ', backgroundColor: 'white', width: '30%' }}>
//   <form onSubmit={handleSubmit}>
//     <label style={{ marginRight: '10px' }}>
//       Quantity:
//       <input
//         type="number"
//         value={quantity}
//         onChange={(event) => setQuantity(event.target.value)}
//         style={{ width: '50px', height: '25px', marginLeft: '10px' }}
//       />
//     </label>
//     <button
//       type="submit"
//       style={{
//         backgroundColor: '#4CAF50',
//         color: 'white',
//         padding: '10px 20px',
//         border: 'none',
//         borderRadius: '5px',
//         cursor: 'pointer',
//       }}
//     >
//       Add to Cart
//     </button>
//     <button
//       type="button"
//       onClick={handleViewCart}
//       style={{
//         backgroundColor: '#4CAF50',
//         color: 'white',
//         padding: '10px 20px',
//         border: 'none',
//         borderRadius: '5px',
//         cursor: 'pointer',
//       }}
//     >
//       View Cart
//     </button>
//     {/* <button type="button" onClick={handleSave} style={{ backgroundColor: '#4CAF50', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer', marginLeft: '10px' }}>Update Cart</button> */}
//   </form>
// </div>
//     </>
//   );
// };

// export default AddCart;

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AddCart.css';
import LoginNavbar from '../Admin/LoginNavbar';

const AddCart = () => {
  const [quantity, setQuantity] = useState(1);
  const [user, setUser] = useState(null);
  const [book, setBook] = useState(null);
  const navigate = useNavigate();
  const [cartData, setCartData] = useState([]);
  const [selectedCart, setSelectedCart] = useState(null);

  useEffect(() => {
    const userFromLocalStorage = JSON.parse(localStorage.getItem('user'));
    const bookFromLocalStorage = JSON.parse(localStorage.getItem('book'));

    if (userFromLocalStorage && bookFromLocalStorage) {
      setUser(userFromLocalStorage);
      setBook(bookFromLocalStorage);
    }

    const fetchCartData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/get/carts/${userFromLocalStorage.id}`);
        setCartData(response.data);
      } catch (error) {
        console.error(error);
      }
    };

    if (userFromLocalStorage) {
      fetchCartData();
    }

  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!user ||!book) {
      alert('User or book not found in local storage');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8080/post/carts', {
        quantity,
        book: { id: book.id },
        user: { id: user.id },
      });

      if (response.status === 200) {
        alert('Cart added successfully');
        navigate("/placeorder");
      } else {
        alert('Failed to add cart');
      }
    } catch (error) {
      console.error(error);
      alert('Failed to add cart');
    }
  };

  const handleViewCart = () => {
    navigate("/viewCart");
  };

  const handleSave = () => {
    axios.put(`http://localhost:8080/put/carts`, {
        id: selectedCart.id,
        quantity: selectedCart.quantity,
        user: { id: selectedCart.user.id },
        book: { id: selectedCart.book.id },
      })
      .then(res => {
        setCartData(cartData.map(cart => cart.id === selectedCart.id ? selectedCart : cart));
        setSelectedCart(null);
        alert("Cart updated successfully");
      })
      .catch(err => {
        console.log(err);
        alert("Error updating cart");
      });
  }

  return (
    <>
      <LoginNavbar/>
      <div style={{ textAlign: 'auto', margin: 'auto', marginTop: '3%',borderRadius:'10%',boxShadow: '0px 0px 10px 1px rgba(0, 0, 0, 0.2)' , alignItems: 'center', padding: '20px', border: '2px solid ', backgroundColor: 'white', width: '30%' }}>
        <form onSubmit={handleSubmit}>
          <label style={{ marginRight: '10px' }}>
            Quantity:
            <input
              type="number"
              value={quantity}
              onChange={(event) => setQuantity(event.target.value)}
              style={{ width: '50px', height: '25px', marginLeft: '10px' }}
            />
          </label>
          <button
            type="submit"
            style={{
              backgroundColor: '#4CAF50',
              color: 'white',
              padding: '10px 20px',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
            }}
          >
Add to Cart
          </button>
          <button
            type="button"
            onClick={handleViewCart}
            style={{
              backgroundColor: '#4CAF50',
              color: 'white',
              padding: '10px 20px',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
            }}
          >
            View Cart
          </button>
          {selectedCart && (
            <>
              <button type="button" onClick={handleSave} style={{ backgroundColor: '#4CAF50', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '5px', cursor: 'pointer', marginLeft: '10px' }}>Update Cart</button>
            </>
          )}
        </form>
        {cartData.length > 0 && (
          <div>
            <h2>Your Cart</h2>
            <ul>
              {cartData.map((cart) => (
                <li key={cart.id}>
                  {cart.book.title} - Quantity: {cart.quantity}
                  <button onClick={() => setSelectedCart(cart)}>Edit</button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </>
  );
};

export default AddCart;
