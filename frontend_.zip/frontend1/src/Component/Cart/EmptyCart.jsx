import React from 'react';
import emptyCartImage from '../Assets/shopping.png';
import { useNavigate } from 'react-router-dom';
import './EmptyCart.css';

const EmptyCart = () => {
  const navigate = useNavigate();

  const handleAddToCartClick = () => {
    navigate('/searchBook');
  };

  return (
    <div className="text-center py-5">
      <img src={emptyCartImage} alt="Empty Cart" className="img-fluid mb-3" />
      <h5 className="font-weight-bold mb-3">Your cart is empty</h5>
      <p className="lead">Add some books to your cart to proceed with your purchase.</p>
      <button className="btn btn-primary" onClick={handleAddToCartClick}>SearchBook</button>
    </div>
  );
};

export default EmptyCart;