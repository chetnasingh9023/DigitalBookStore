import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './ViewBook.css';
import AdminLoginNavbar from '../Admin/AdminLoginNavbar';
import { toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

function ViewBook() {
  const [bookData, setBookData] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    getBooks();
  }, []);

  const getBooks = () => {
    axios.get('http://localhost:8080/books')
     .then(res => {
        setBookData(res.data);
        console.log(res.data);
      })
     .catch(err => {
        console.log(err);
      });
  }
console.log(bookData)
  const handleDelete = (bookId) => {
    console.log(bookId);
    axios.delete(`http://localhost:8080/books/${bookId}`)
     .then(res => {
        setBookData(bookData.filter(book => book.id!== bookId));
        toast.success('Book deleted successfully');
        getBooks();
      })
     .catch(err => {
        console.log(err);
        toast.error('Error deleting book');
      });
  }

  const handleUpdate = (bookId) => {
    const bookToUpdate = bookData.find(book => book.id === bookId);
    setSelectedBook(bookToUpdate);
  }

  const handleSave = () => {
     axios.put(`http://localhost:8080/post/${selectedBook.id}`, selectedBook)
      .then(res => {
         setBookData(bookData.map(book => book.id === selectedBook.id? selectedBook : book));
         toast.success('Book updated successfully');
         setSelectedBook(null);
         toast.success('Book updated successfully');
       })
      .catch(err => {
         console.log(err);
         toast.error('Error updating book');
       });
   }
  const onAddBook = () => {
    navigate('/addBook');
  }

  const handleSelect = (id, value) => {
    if (value === 'update') {
      handleUpdate(id);
    } else if (value === 'delete') {
      handleDelete(id);
    }
  };

  const getBookById = (id) => {
    return bookData.find(book => book.id === id);
  }

  const getimageUrl = (book) => {
    const storedBook = JSON.parse(localStorage.getItem('books')) || [];
    const storedBookObj = storedBook.find(b => b.id === book.id);
    return storedBookObj?.imageUrl || '';
  }

  return (
    <>
      <AdminLoginNavbar />
      <div className="back">
      <div className="row" style={{ marginTop: 50, width: '100%', display: 'flex', justifyContent: 'center' }}>
        <div className="col-md-10" style={{ backgroundColor: '#f2f2f2', padding: 0, borderRadius: 5 }}>
          {!selectedBook && (
            <table className="table table-bordered table-striped">
              <thead style={{ backgroundColor: '#ddd' }}>
                <tr>
                  <th>Book Id</th>
                  <th>Book Name</th>
                  <th>Description</th>
                  <th>Unit Price</th>
                  <th>Author</th>
                  <th>Publisher</th>
                  <th>Units In Stock</th>
                  <th>Image URL</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {bookData.map((book, index) => (
                  <tr key={index}>
                    <td>{book.id}</td>
                    <td>{book.name}</td>
                    <td>{book.description}</td>
                    <td>{book.unitPrice}</td>
                    <td>{book.author}</td>
                    <td>{book.publisher}</td>
                    <td>{book.unitsInStock}</td>
                    <td><img src={book.imageUrl}/> </td>
                    <td>
                      <div className="d-flex">
                        <button type="button" className={`btn btn-warning ${selectedBook && selectedBook.id === book.id? 'disabled' : ''}`} style={{ width: 80 }} onClick={() => handleSelect(book.id, 'update')}>Update</button>
                       <button type="button" className={`btn btn-danger ${selectedBook && selectedBook.id === book.id? 'disabled' : ''}`} style={{ width: 80, backgroundColor:'red', marginRight: 10 }} onClick={() => handleSelect(book.id, 'delete')}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
          
      <div className="col-md-10" style={{ marginTop: 50, width: '100%', display: 'flex',  justifyContent: 'center' }}>

          {selectedBook && (
            <>
            <div className="row" style={{ marginTop: 50, width: '40%', marginLeft: 'auto',display:'flex',justifyContent:'center', marginRight: 'auto' }}>
            <div className="col-md-10" style={{ backgroundColor: '#f2f2f2', padding: 20, borderRadius: 5, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <h1 style={{ textAlign: 'center', marginBottom: 30 }}>Update Book Details</h1>
              <form style={{ width: '100%' }}>
                <label htmlFor="name" style={{ display: 'block', marginBottom: 10 }}>Book Name:</label>
                <input type="text" id="name" name="name" value={selectedBook.name} onChange={(e) => setSelectedBook({...selectedBook, name: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="description" style={{ display: 'block', marginBottom: 10 }}>Description:</label>
                <input type="text" id="description" name="description" value={selectedBook.description} onChange={(e) => setSelectedBook({...selectedBook, description: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="unitPrice" style={{ display: 'block', marginBottom: 10 }}>Unit Price:</label>
                <input type="number" id="unitPrice" name="unitPrice" step="0.01" value={selectedBook.unitPrice} onChange={(e) => setSelectedBook({...selectedBook, unitPrice: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="author" style={{ display: 'block', marginBottom: 10 }}>Author:</label>
                <input type="text" id="author" name="author" value={selectedBook.author} onChange={(e) => setSelectedBook({...selectedBook, author: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="publisher" style={{ display: 'block', marginBottom: 10 }}>Publisher:</label>
                <input type="text" id="publisher" name="publisher" value={selectedBook.publisher} onChange={(e) => setSelectedBook({...selectedBook, publisher: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="unitsInStock" style={{ display: 'block', marginBottom: 10 }}>Units In Stock:</label>
              <input type="number" id="unitsInStock" name="unitsInStock" value={selectedBook.unitsInStock} onChange={(e) => setSelectedBook({...selectedBook, unitsInStock: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <label htmlFor="imageUrl" style={{ display: 'block', marginBottom: 10 }}>Image URL:</label>
                <input type="text" id="imageUrl" name="imageUrl" value={selectedBook.imageUrl} onChange={(e) => setSelectedBook({...selectedBook, imageUrl: e.target.value })} style={{ width: '100%', padding: 5, marginBottom: 20, borderRadius: 5, border: '1px solid #ccc' }} /><br />
          
                <button type="submit" onClick={handleSave} style={{ backgroundColor: '#4CAF50', color: 'white', padding: 10, border: 'none', borderRadius: 5, cursor: 'pointer' }}>Save Book</button>
              </form>
            </div>
          </div>
            </>
          )}
      </div>
      
      </div>
    </>
  );
}

export default ViewBook;


