
import './AddBook.css';
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
 
import AdminLoginNavbar from '../Admin/AdminLoginNavbar';
 
function AddBook() {
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [description, setDescription] = useState("");
  const [unitPrice, setUnitPrice] = useState("");
  const [author, setAuthor] = useState("");
  const [publisher, setPublisher] = useState("");
  const [unitsInStock, setUnitsInStock] = useState("");
  const [dateCreated, setDateCreated] = useState("");
  const [lastUpdated, setLastUpdated] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const navigate = useNavigate();
 
  const checkAdmin = () => {
    const role = localStorage.getItem('role');
    if (role === "Admin") {
      navigate('/AddBook');
    }
 
   
  }
 
  function onsubmit() {
    console.log(name);
    axios.post('http://localhost:8080/post/books', {
      name,
      imageUrl,
      description,
      unitPrice,
      author,
      publisher,
      unitsInStock,
      // dateCreated,
      // lastUpdated,
       category: {
        id: categoryId,
        // categoryName
      }
    })
    .then((res) => {
      console.log(res);
      alert("Added successfully");
       navigate('/viewBook');
    });
  } 
  return (
    <>

      <AdminLoginNavbar />
      <h1 style={{textAlign:'center'}}>Add new Book</h1>
      

      {checkAdmin()}
          
        <div className="container mt-5" style={{ width: "500px", margin: "0 auto", padding: "20px", backgroundColor:"white" }}>
          
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" onChange={(e)=>setName(e.target.value)} required /><br /><br />
 
        <label htmlFor="imageUrl">Image Url:</label>
        <input type="text" id="imageUrl" name="imageUrl" onChange={(e)=>setImageUrl(e.target.value)} /><br /><br />

        <label htmlFor="description">Description:</label>
        <input type="text" id="description" name="description" onChange={(e)=>setDescription(e.target.value)} /><br /><br />
 
        <label htmlFor="unitPrice">Unit Price:</label>
        <input type="number" id="unitPrice" name="unitPrice" min="0" onChange={(e)=>setUnitPrice(e.target.value)} /><br /><br />
 
        <label htmlFor="author">Author:</label>
        <input type="text" id="author" name="author" onChange={(e)=>setAuthor(e.target.value)} /><br /><br />
 
        <label htmlFor="publisher">Publisher:</label>
        <input type="text" id="publisher" name="publisher" onChange={(e)=>setPublisher(e.target.value)} /><br /><br />
 
        <label htmlFor="unitsInStock">Units In Stock:</label>
        <input type="number" id="unitsInStock" min="0" name="unitsInStock" onChange={(e)=>setUnitsInStock(e.target.value)}  /><br /><br />
 
        {/* <label htmlFor="dateCreated">Date Created:</label>
        <input type="date" id="dateCreated" name="dateCreated" onChange={(e)=>setDateCreated(e.target.value)} /><br /><br />
 
        <label htmlFor="lastUpdated">Last Updated:</label>
        <input type="date" id="lastUpdated" name="lastUpdated" onChange={(e)=>setLastUpdated(e.target.value)} /><br /><br /> */}
 
 
        <label htmlFor="categoryId">Category Id:</label>
        <input type="number" id="categoryId" min="0" name="categoryId" onChange={(e)=>setCategoryId(e.target.value)} /><br /><br />
 
        {/* <label htmlFor="categoryName">Category Name:</label>
        <input type="text" id="categoryName" name="categoryName" onChange={(e)=>setCategoryName(e.target.value)} /><br /><br/> */}
 
        <button className='addProductButton' type="submit" onClick={onsubmit}>Add</button>
      </div>
      
    </>
  );
}
 
export default AddBook;

