package com.cts.digital.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cts.digital.entity.Contact;
import com.cts.digital.repository.ContactRepository;
import com.cts.digital.service.ContactService;

@SpringBootTest
public class ContactTest {

    @MockBean
    private ContactRepository cr;

    @Autowired
    private ContactService cs;

    @Test
    public void testCreateContact() {
        Contact contact = new Contact();
        contact.setName("John");
        contact.setEmail("john.doe@example.com");
        contact.setPhoneNumber("8292086686");
        contact.setFeedback("very good");

        Contact savedContact = new Contact();
        savedContact.setId(1L);
        savedContact.setName("John");
        savedContact.setEmail("john.doe@example.com");
        contact.setPhoneNumber("8292086686");
        contact.setFeedback("very good");


        when(cr.save(contact)).thenReturn(savedContact);

        Contact result = cs.createContact(contact);

        assertEquals(savedContact, result);
    }

    @Test
    public void testRetrieveAllContact() {
        List<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact( "John", "john.doe@example.com","8292086686","very good"));
        contacts.add(new Contact( "Jane","jane.doe@example.com","8292635670","very nice"));

        when(cr.findAll()).thenReturn(contacts);

        List<Contact> result = cs.retrieveAllContact();

        assertEquals(contacts, result);
    }

}