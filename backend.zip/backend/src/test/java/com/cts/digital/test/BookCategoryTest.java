package com.cts.digital.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.digital.entity.BookCategory;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookCategoryRepository;
import com.cts.digital.service.BookCategoryService;

public class BookCategoryTest {

    @Mock
    private BookCategoryRepository repository;

    @InjectMocks
    private BookCategoryService service;

    private List<BookCategory> categoryList;
    private BookCategory category;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        categoryList = new ArrayList<>();
        category = new BookCategory();
        category.setId(1L);
        category.setCategoryName("Test Category");
        categoryList.add(category);
    }

    @Test
    public void testRetrieveAll() {
        when(repository.findAll()).thenReturn(categoryList);
        List<BookCategory> result = service.retrieveAll();
        assertEquals(categoryList, result);
    }

    @Test
    public void testRetrieveAllEmpty() {
        when(repository.findAll()).thenReturn(new ArrayList<>());
        assertThrows(ThrowValidException.class, () -> service.retrieveAll());
    }

    @Test
    public void testRetrieveById() {
        when(repository.findById(category.getId())).thenReturn(Optional.of(category));
        BookCategory result = service.retrieveById(category.getId());
        assertEquals(category, result);
    }

    @Test
    public void testRetrieveByIdNotFound() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(ThrowValidException.class, () -> service.retrieveById(1L));
    }

    @Test
    public void testUpdateBookCategory() {
        when(repository.findById(category.getId())).thenReturn(Optional.of(category));
        BookCategory updatedCategory = new BookCategory();
        updatedCategory.setId(category.getId());
        updatedCategory.setCategoryName("Updated Test Category");
        when(repository.save(any())).thenReturn(updatedCategory);
        BookCategory result = service.updateBookCategory(updatedCategory);
        assertEquals(updatedCategory, result);
    }

    @Test
    public void testUpdateBookCategoryNotFound() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        BookCategory updatedCategory = new BookCategory();
        updatedCategory.setId(1L);
        assertThrows(ThrowValidException.class, () -> service.updateBookCategory(updatedCategory));
    }

//    @Test
//    public void testCreateBookCategory() {
//        when(repository.findById(category.getId())).thenReturn(Optional.empty());
//        when(repository.save(any())).thenReturn(category);
//        BookCategory result = service.createBookCategory(category);
//        assertNotNull(result);
//        assertEquals(category, result);
//    }

//    @Test
//    public void testCreateBookCategoryIdNotNull() {
//        category.setId(1L);
//        assertThrows(ThrowValidException.class, () -> service.createBookCategory(category));
//    }

    @Test
    public void testDeleteCategory() {
        when(repository.findById(category.getId())).thenReturn(Optional.of(category));
        service.deleteCategory(category.getId());
    }

    @Test
    public void testDeleteCategoryNotFound() {
        when(repository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(ThrowValidException.class, () -> service.deleteCategory(1L));
    }
}