package com.cts.digital.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.digital.entity.Book;
import com.cts.digital.entity.BookCategory;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookCategoryRepository;
import com.cts.digital.repository.BookRepository;
import com.cts.digital.service.BookService;

@ExtendWith(MockitoExtension.class)
public class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @Mock
    private BookCategoryRepository bookCategoryRepository;

    @InjectMocks
    private BookService bookService;

    private Book book;
    private BookCategory bookCategory;

    @BeforeEach
    public void setup() {
        bookCategory = new BookCategory();
        bookCategory.setId(1L);;
        bookCategory.setCategoryName("Test Category");

        book = new Book();
        book.setId(1L);
        book.setName("Test Book");
        book.setCategory(bookCategory);
    }

    @Test
    public void testRetrieveAllBook() {
        List<Book> bookList = new ArrayList<>();
        bookList.add(book);

        when(bookRepository.findAll()).thenReturn(bookList);

        List<Book> result = bookService.retrieveAllBook();

        assertEquals(bookList, result);
    }

    @Test
    public void testRetrieveBookById() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));

        Book result = bookService.retrieveBookById(1L);

        assertEquals(book, result);
    }

    @Test
    public void testRetrieveBookById_BookNotFound() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.empty());

        ThrowValidException exception = assertThrows(ThrowValidException.class, () -> bookService.retrieveBookById(1L));

        assertEquals("Book not exits", exception.getMessage());
    }

  
    @Test
    public void testSearchBook_BookNotFound() {
        when(bookRepository.findAll()).thenReturn(new ArrayList<>());

        Book result = bookService.searchBook("Test Book");

        assertEquals(null, result);
    }

    @Test
    public void testUpdateBook() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));

        bookService.updateBook(book);

        verify(bookRepository, times(1)).save(any());
    }

    @Test
    public void testUpdateBook_BookNotFound() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.empty());

        ThrowValidException exception = assertThrows(ThrowValidException.class, () -> bookService.updateBook(book));

        assertEquals("book id is not found", exception.getMessage());
    }
    

   
 
}