package com.cts.digital.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="book")

public class Book {

	//public static final String HttpStatus = null;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@Column(name="name",nullable=false)
	private String name;
	private String imageUrl;
	
	@Column(name="description")
	private String description;
	
	@Column(name="unit_price",nullable=false)
	//private BigDecimal unitPrice;
	private Double unitPrice;
	
	@Column(name="author-name")
	private String author;
	
	@Column(name="publisher-name")
	private String publisher;

	
	
	@Column(name="units_in_stock",nullable=false)//it can't accept null
	private Integer unitsInStock;
	
	@Column(name="date_created")
	@CreationTimestamp
	private LocalDate dateCreated;
	
	@Column(name="last_updated")
	@UpdateTimestamp
	private LocalDate lastUpdated;
	
	
	@ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private BookCategory category;
	
	@JsonIgnore
	@OneToMany(mappedBy="book",cascade=CascadeType.ALL)
	private Set<Cart> cart = new HashSet<>();
	
	@JsonIgnore
	@OneToMany(mappedBy="book",cascade=CascadeType.ALL)
	private Set<OrderItems> orderItems = new HashSet<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Integer getUnitsInStock() {
		return unitsInStock;
	}

	public void setUnitsInStock(Integer unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDate getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(LocalDate lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public BookCategory getCategory() {
		return category;
	}

	public void setCategory(BookCategory category) {
		this.category = category;
	}

	public Set<Cart> getCart() {
		return cart;
	}

	public void setCart(Set<Cart> cart) {
		this.cart = cart;
	}

	public Set<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(Set<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}

	public Book(Long id, String name, String imageUrl, String description, Double unitPrice, String author,
			String publisher, Integer unitsInStock, LocalDate dateCreated, LocalDate lastUpdated, BookCategory category,
			Set<Cart> cart, Set<OrderItems> orderItems) {
		super();
		this.id = id;
		this.name = name;
		this.imageUrl = imageUrl;
		this.description = description;
		this.unitPrice = unitPrice;
		this.author = author;
		this.publisher = publisher;
		this.unitsInStock = unitsInStock;
		this.dateCreated = dateCreated;
		this.lastUpdated = lastUpdated;
		this.category = category;
		this.cart = cart;
		this.orderItems = orderItems;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", imageUrl=" + imageUrl + ", description=" + description
				+ ", unitPrice=" + unitPrice + ", author=" + author + ", publisher=" + publisher + ", unitsInStock="
				+ unitsInStock + ", dateCreated=" + dateCreated + ", lastUpdated=" + lastUpdated + ", category="
				+ category + ", cart=" + cart + ", orderItems=" + orderItems + "]";
	}
	
	
	

}
