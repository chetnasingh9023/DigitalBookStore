
package com.cts.digital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.digital.entity.Book;
import com.cts.digital.entity.Cart;
import com.cts.digital.entity.Order;
import com.cts.digital.entity.OrderItems;
import com.cts.digital.entity.User;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookRepository;
import com.cts.digital.repository.CartRepository;
import com.cts.digital.repository.OrderItemsRepository;
import com.cts.digital.repository.OrderRepository;
import com.cts.digital.repository.UserRepository;

@Service

public class OrderService {

	@Autowired
	OrderRepository orderRepo;

	@Autowired
	BookRepository productRepo;

	@Autowired
	CartRepository cartRepo;

	@Autowired
	OrderItemsRepository itemRepo;

	@Autowired
	UserRepository userRepo;

	public List<Order> retrieveAllOrders() {
		List<Order> orderList = orderRepo.findAll();
		if (orderList.isEmpty()) {
			throw new ThrowValidException("There are no orders yet");
		}
		return orderList;
	}
	
	public Order retrieveOrderById(Long idd) {
		try {
			Order order = orderRepo.findById(idd).get();
			return order;
		} catch (Exception e) {
			throw new ThrowValidException("Wrong order id:" + idd);
		}
	}
	//order placed means confirm order
	public Order placeOrder(Order order) {
		List<Order> orderList = orderRepo.findAll();
		order.setOrderTrackingNumber("OTN-" + (orderList.size() + 1));
		List<Cart> cartList = cartRepo.findByUserId(order.getUser().getId());
		Integer quantity = 0;
		Double price = 0.0;
		for (Cart i : cartList) {
			quantity += i.getQuantity();
			price += i.getPrice();
		}
		order.setTotalQuantity(quantity);
		order.setTotalPrice(price);
		order.setStatus("Processed");
		order.setUser(userRepo.findById(order.getUser().getId()).get());
		Order order2 = orderRepo.save(order);
		for (Cart i : cartList) {
			OrderItems orderItem = new OrderItems(i.getQuantity(), i.getPrice(),
					order2, i.getBook());
			Book b = productRepo.findById(i.getBook().getId()).get();
			b.setUnitsInStock(b.getUnitsInStock() - i.getQuantity());
			productRepo.save(b);
			itemRepo.save(orderItem);
			cartRepo.deleteById(i.getId());
		}
		return order2;
	}
	
	public void removeOrder(Long id) {
		retrieveOrderById(id); // checked in retrieveOrderById
		orderRepo.deleteById(id);
	}

	public Order updateOrder(Order order) {
		return orderRepo.save(order);
	}

	public Order getByOrderTrackingNumber(String trackingNumber) {
		Order o = orderRepo.getByOrderTrackingNumber(trackingNumber);
		return o;
	}
	
	public List<Order> findOrdersByUserId(Long userId) {
	    User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
	    return orderRepo.findByUser(user);
	}
}
