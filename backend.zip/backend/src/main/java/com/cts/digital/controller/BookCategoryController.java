package com.cts.digital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.digital.entity.BookCategory;
import com.cts.digital.service.BookCategoryService;

@RestController
@CrossOrigin(origins = "*")
public class BookCategoryController {

	@Autowired
	BookCategoryService service;
	
	
	//insert category in database 
	@PostMapping("post/categories")
	public ResponseEntity<BookCategory> createCategory(@RequestBody BookCategory obj){
		BookCategory c = service.createBookCategory(obj);
		return new ResponseEntity<> (c,HttpStatus.CREATED);
	}

	//Get all Category
	@GetMapping("/categories")
	public ResponseEntity<List<BookCategory>> retrieveAll(){
		 List<BookCategory> categoryList = service.retrieveAll();
		 return new ResponseEntity<>(categoryList,HttpStatus.OK);
	}
	
	//Get Category By Id
	@GetMapping("/categories/{id}")
	public ResponseEntity<BookCategory> retrieveCategoryById(@PathVariable Long id){
		 BookCategory category = service.retrieveById(id);
		 return new ResponseEntity<>(category,HttpStatus.OK);
	}
	
	//update new Category
	@PutMapping("/put/categories")
	public ResponseEntity<BookCategory> updateCategory(@RequestBody BookCategory obj){
		 BookCategory category = service.updateBookCategory(obj);
		 return new ResponseEntity<>(category,HttpStatus.CREATED);
	}
	
	//delete by category id
	@DeleteMapping("/categories/{id}")
	public String removeCategory(@PathVariable Long id){
		service.deleteCategory(id);
		return "Category removed from data";
	}
	
}
