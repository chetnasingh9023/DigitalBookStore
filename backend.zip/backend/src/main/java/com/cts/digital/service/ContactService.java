package com.cts.digital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.digital.entity.Contact;
import com.cts.digital.repository.ContactRepository;

@Service
public class ContactService {
	@Autowired
	ContactRepository cr;
	
	
	
	public Contact createContact(Contact obj) {
		Contact c = null;
		cr.findAll();
		c = cr.save(obj);
	
	return c;
	}
	public List<Contact> retrieveAllContact() {
		List<Contact> lis = cr.findAll();
		return lis;
		
		
	}



	

}
