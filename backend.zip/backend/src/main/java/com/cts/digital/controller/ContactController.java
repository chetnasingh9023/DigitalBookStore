package com.cts.digital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.digital.entity.Contact;
import com.cts.digital.service.ContactService;

@RestController
@CrossOrigin(origins = "*")

public class ContactController {

	@Autowired
	ContactService cs;
//insert contact details in database
@PostMapping("/post/contact")
ResponseEntity<Contact> createContact(@RequestBody Contact obj) {
	return new ResponseEntity<>(cs.createContact(obj),HttpStatus.OK);
}
//get contact details by database
@GetMapping("/contact")
public ResponseEntity<List<Contact>> getAllContacts() {
    return new ResponseEntity<List<Contact>>(cs.retrieveAllContact(),HttpStatus.OK);
}

	
}


