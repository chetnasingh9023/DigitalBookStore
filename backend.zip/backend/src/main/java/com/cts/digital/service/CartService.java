package com.cts.digital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.digital.entity.Book;
import com.cts.digital.entity.Cart;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookRepository;
import com.cts.digital.repository.CartRepository;
import com.cts.digital.repository.UserRepository;

@Service
public class CartService  {

	@Autowired
	CartRepository cr;

	@Autowired
	BookRepository pr;
	
	@Autowired
	UserRepository ur;

	
	public List<Cart> retrieveAll() {
		List<Cart> cartList = cr.findAll();
		if (cartList.isEmpty()) {
			throw new ThrowValidException("There are not any item selected");
		}
		return cartList;
	}

	
	public Cart createCart(Cart obj) {
//if  user selected book is already in cart then we can  update quantity and price of book

		try {
			List<Cart> cartList = cr.findAll();
			if (cartList != null) {
				for (Cart i : cartList) {
					if (i.getUser().getId() == obj.getUser().getId()) {
						if (i.getBook().getId() == obj.getBook().getId()) {
							Double price = i.getPrice();

							Book book = pr.findById(obj.getBook().getId()).get();
							Double unitPrice = book.getUnitPrice();
							//i.setPrice((unitPrice.multiply(BigDecimal.valueOf(obj.getQuantity()))).add(price));
							i.setPrice((unitPrice*obj.getQuantity())+price);
							i.setQuantity(obj.getQuantity() + i.getQuantity());
							return cr.save(i);
						}
					}
				}
			}
			//create new cart of book if book is not in cart then by this we will create new cart and in this we have to add 
			//price and quantity then new details add in cart u can view in cart then 
			Book book = pr.findById(obj.getBook().getId()).get();
			Double unitPrice = book.getUnitPrice();
			obj.setPrice(unitPrice*obj.getQuantity());
			
			obj.setBook(book);
			obj.setUser(ur.findById(obj.getUser().getId()).get());
			Cart cart = cr.save(obj);
			
			return cart;
		} catch (Exception e) {
			throw new ThrowValidException("Select book not exists in database");
		}
	}

	
	public void removeCart(Long id) {
		try {
			Cart cart = cr.findById(id).get();
			cr.deleteById(id);
		} catch (Exception e) {
			throw new ThrowValidException("Sorry something went wrong");
		}

	}

//putMapping(new updation of book in a cart )
	public Cart updateCart(Cart obj) {
		try {
			cr.findById(obj.getId()).get();
			Book book = pr.findById(obj.getBook().getId()).get();
			double unitPrice = book.getUnitPrice();
			obj.setPrice(unitPrice*obj.getQuantity());
			Cart cart = cr.save(obj);
			return cart;
		} catch (Exception e) {
			throw new ThrowValidException("Something wrong input");
		}
	}

}
