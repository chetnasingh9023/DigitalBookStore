package com.cts.digital.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.digital.entity.Book;
import com.cts.digital.entity.BookCategory;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookCategoryRepository;
import com.cts.digital.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	BookRepository pr;

	@Autowired
	BookCategoryRepository repo;

	public Book findByIdAndName(Long id,String name) {
		Book book = pr.findByIdAndName(id ,name);
		return book;
	}

	public List<Book> retrieveAllBook() {
		List<Book> bookList = pr.findAll();
		if (bookList.isEmpty()) {
			throw new ThrowValidException("There are no Book");
		}
		return bookList;
	}

	public Book retrieveBookById(Long idd) {
		Optional<Book> book = pr.findById(idd);
		try {
			return book.get();
		} catch (Exception e) {
			throw new ThrowValidException("Book not exits");
		}
	}

	public Book searchBook(String name) {
		Book book = null;
		List<Book> list = pr.findAll();
		for (Book b : list) {
			if (b.getName().equals(name)) {
				book = pr.findById(b.getId()).orElse(null);

			}
		}
		return book;
	}

	public String updateBook(Book obj) {
		String s = null;

		try {
			if (pr.findById(obj.getId()).get() != null) {
				// pr.findById(obj.getId()).get();
				pr.save(obj);
				s = "updated successfully!!";

			}

		} catch (Exception e) {
			throw new ThrowValidException("book id is not found");

		}
		return s;
	}
//create book means add book
	public Book createBook(Book obj) {
	    Book book = null;
	    try {
	        if (obj.getId()==null) {
	            Long id = obj.getCategory().getId();
	            Optional<BookCategory> category = repo.findById(id);
	            if (category.isPresent()) {
	                book = pr.save(obj);
	            }
            else {
	                throw new ThrowValidException("category is not in record");
	            }
	        }
	    } catch (Exception e) {
	        throw new ThrowValidException("category is not in record");
	    }
	    return book;
	}



	public void removeBook(Long id) {
		try {
			pr.findById(id).get();
			pr.deleteById(id);
		} catch (Exception e) {
			throw new ThrowValidException("Id:" + id + " Invalid Book");
		}
	}
	
	public List<Book> searchByCategoryName(String cat) {
			List<Book> newlist=new ArrayList<>();
			List<Book> list=pr.findAll();
			for(Book b:list) {
				if(b.getCategory().getCategoryName().equalsIgnoreCase(cat)) {
					newlist.add(b);
				}
			}
			return newlist;
	}

}
