package com.cts.digital.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.digital.entity.Order;
import com.cts.digital.entity.User;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long>{
	

	



	public Order getByOrderTrackingNumber(String trackingNumber);

	public List<Order> findByUser(User user);



}
