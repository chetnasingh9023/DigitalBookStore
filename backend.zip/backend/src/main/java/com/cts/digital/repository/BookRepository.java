package com.cts.digital.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.digital.entity.Book;

@Repository
//it means this repository is only responsible for managing and retrieving data from book table
public interface BookRepository extends JpaRepository<Book, Long> {

	void deleteByCategoryId(Long id);

	// Book findByIdandName(String name,Long Id );

	Book findByIdAndName(Long id, String name);

}
