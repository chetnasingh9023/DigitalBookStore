package com.cts.digital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.digital.entity.Book;
import com.cts.digital.service.BookCategoryService;
import com.cts.digital.service.BookService;

@RestController
@CrossOrigin(origins = "*")
public class BookController {

	@Autowired
	BookService service;

	@Autowired
	private BookCategoryService bookCategoryService;



	// Add New Product
	@PostMapping("/post/books")
	public ResponseEntity<Book> createBook(@RequestBody Book obj) {
		Book book = service.createBook(obj);
		return new ResponseEntity<>(book, HttpStatus.CREATED);
	}

	// Get product List
	@GetMapping("/books")
	public ResponseEntity<List<Book>> retrieveAll() {
		List<Book> bookList = service.retrieveAllBook();
		return new ResponseEntity<>(bookList, HttpStatus.OK);
	}

	// Get product By Id
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> retrieveBookById(@PathVariable Long id) {
		Book book = service.retrieveBookById(id);
		return new ResponseEntity<>(book, HttpStatus.OK);
	}
    //search by book name
	@GetMapping("/b/{name}")
	public ResponseEntity<Book> searchBook(@PathVariable String name) {
		return new ResponseEntity<Book>(service.searchBook(name), HttpStatus.OK);
	}
	//search by category name then book list will come
	@GetMapping("/cat/{name}")
	public ResponseEntity<List<Book>> searchByCategoryName(@PathVariable String name){
		return new ResponseEntity<List<Book>>(service.searchByCategoryName(name),HttpStatus.OK);
	}
	//find by book id 
	@GetMapping("/b/{id}/{name}")
	public ResponseEntity<Book> findBookByIdandName(@PathVariable Long id, @PathVariable String name){
		return new ResponseEntity<Book>(service.findByIdAndName(id,name), HttpStatus.OK);
	}

	
	@PutMapping("/post/{id}")
		public ResponseEntity<String> updateBook(@PathVariable Long id ,@RequestBody Book book) {
			String message = service.updateBook(book);
			return new ResponseEntity<>(message, HttpStatus.CREATED);
		}
	// Delete Product by Id
	@DeleteMapping("/books/{id}")
	public String deleteBook(@PathVariable Long id) {
		service.removeBook(id);
		return "Book removed";
	}

}
