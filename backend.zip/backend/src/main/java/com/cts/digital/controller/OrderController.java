package com.cts.digital.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.digital.entity.Order;
import com.cts.digital.entity.User;
import com.cts.digital.service.OrderService;
import com.cts.digital.service.UserService;

@RestController
@CrossOrigin(origins = "*")

public class OrderController {

	@Autowired
	private OrderService service;

	@Autowired
	private UserService us;

	// Create new Order(there is user)
	@PostMapping("/post/orders")
	public Order saveOrder(@RequestBody Order order) {

		Order order2 = service.placeOrder(order);
		User user = us.findOne(order2.getUser().getId());
		user.setTotalOrder((user.getTotalOrder() != 0 ? user.getTotalOrder() : 0) + 1);
		us.update(user);
		return order2;
	}

	// Get all Orders
	@GetMapping("/orders")
	public List<Order> retrieveAllOrders() {
		List<Order> OrderList = service.retrieveAllOrders();
		return OrderList;
	}
//   get order details by tracking number of order
    @GetMapping("/{trackingNumber}")
    public ResponseEntity<Order> getByOrderTrackingNumber(@PathVariable String trackingNumber) {
       return new ResponseEntity<Order>(service.getByOrderTrackingNumber(trackingNumber),HttpStatus.OK);
    }

	// Get Order by id
	@GetMapping("/orders/{id}")
	public Order retrieveOrder(@PathVariable Long id) {
		Order order2 = service.retrieveOrderById(id);
		return order2;
	}
	//update order
	@PutMapping("/put/orders")
	public Order updateOrder(@RequestBody Order order) {
		Order order2 = service.updateOrder(order);
		return order2;
	}

	// Delete a order
	@DeleteMapping("/orders/{id}")
	public String deleteOrder(@PathVariable Long id) {
		service.removeOrder(id);
		return "Order record get deleted";
	}
	//get order details by user id 
	@GetMapping("/order/user/{userId}")
    public ResponseEntity<List<Order>> findOrdersByUserId(@PathVariable Long userId) {
        List<Order> orders = service.findOrdersByUserId(userId);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }
	

}
