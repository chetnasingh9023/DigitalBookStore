package com.cts.digital.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.digital.entity.BookCategory;
import com.cts.digital.exception.ThrowValidException;
import com.cts.digital.repository.BookCategoryRepository;

@Service
public class BookCategoryService {

	@Autowired
	BookCategoryRepository repository;

	
	
	// get category list 
	public List<BookCategory> retrieveAll() {
		List<BookCategory> categoryList = repository.findAll();
		if (categoryList.isEmpty()) {
			throw new ThrowValidException("There are no book categories");
		}
		return categoryList;
	}

	public BookCategory retrieveById(Long id) {
		Optional<BookCategory> category = repository.findById(id);
		try {
			return category.get();
		} catch (Exception e) {
			throw new ThrowValidException("Id:" + id + " is Wrong category");
		}
	}
//update category 
	public BookCategory updateBookCategory(BookCategory obj) {
            BookCategory  b = null;
			try {
				if(repository.findById(obj.getId()).get() != null) {
				//repository.findById(obj.getId()).get();
			     b =repository.save(obj);
			     }
			     }
				catch (Exception e) {
				throw new ThrowValidException("Category out of record so cannot update it");
				}
				return b;
	}
	//create new category
	public BookCategory createBookCategory(BookCategory obj) {
		BookCategory c =null;
		try {
			if(obj.getId()==null) {
			//repository.findById(obj.getId()).get();
			c=repository.save(obj);
			}
		}catch(Exception e) {
			throw new ThrowValidException("Can't created new Category");
		}
		return c;
	}
		
	

		

	public void deleteCategory(Long id) {
		try {
			repository.findById(id).get();
			repository.deleteById(id);
		}catch(Exception e) {
			throw new ThrowValidException("Id:" + id + " Invalid Category");
		}
	}
}
